clear;
clf;
%find crossing of (min+max)/2
data = csvread('distance_1(1).csv');
%data = csvread('zoom_data_2000000_hz.csv');
delay_arr = [];
for i = 370
    ends_cut = i;
    %data = csvread('zoom_data_2000000_hz.csv');
    sync = data(:,1);
    signal1_raw = data(:,2);
    signal2_raw = data(:,3);
    signal1 = smooth(signal1_raw,50);
    signal2 = smooth(signal2_raw,50);
    %zero mean the data
    signal1 = signal1-mean(signal1);
    signal2 = signal2-mean(signal2);
    signal1_raw = signal1_raw-mean(signal1);
    signal2_raw = signal2_raw-mean(signal2);
    %normalize
    [signal1, PS] = mapminmax(signal1');
    [signal2, PS] = mapminmax(signal2');
    [signal1_raw, PS] = mapminmax(signal1_raw');
    [signal2_raw, PS] = mapminmax(signal2_raw');
    signal1 = signal1';
    signal2 = signal2';
    signal1_raw = signal1_raw';
    signal2_raw = signal2_raw';
    %ends_cut = 70;
    signal1 = [zeros(1,ends_cut) signal1((ends_cut+1):(1000-round(ends_cut/5)))' zeros(1,round(ends_cut/5))]';
    %signal2 = [zeros(1,ends_cut) signal2((ends_cut+1):(1000-ends_cut))' zeros(1,ends_cut)]';
    xRange = data(1,4);

    max1 = max(signal1);
    min1 = min(signal1);
    max2 = max(signal2);
    min2 = min(signal2);

    mid1 = (abs(max1)+abs(min1)) / 3 + min1;
    mid2 = (abs(max2)+abs(min2)) / 3 + min2;

    idx1 = 1;
    for i = 1:1000
        if signal1(i) < mid1
            idx1 = i;
        end
    end
    idx2 = 1;
    for i = 1:1000
        if signal2(i) < mid2 && signal2(i) ~= 0
            idx2 = i;
        end
    end
    diff = idx1-idx2;
    fprintf('precision: %d, crossing1: %i, crossing2: %i\n',xRange/1000, idx1, idx2);
    time_diff = diff * xRange/1000;
    dlmwrite('time_diff.txt', time_diff, '-append');

    %plot data signal vs time
    data_points = size(signal1.');
    x = linspace(-xRange/2,xRange/2,data_points(2));
    hold on;
    plot(x,signal1,'b');
    plot(x,signal1_raw,'color',[.8 .8 1]);
    %yyaxis right;
    plot(x,signal2,'r');
    plot(x,signal2_raw,'color',[1 .8 .8]);
    %plot(x,[signal1(diff:end)' zeros(1,diff-1)],'c');
    y1=get(gca,'ylim');
    x1 = x(idx1);
    plot([x1 x1],y1, 'Color', 'b');

    plot([x(idx2) x(idx2)],y1, 'Color', 'r');
    hold off
    ax = gca;
    ax.XAxis.Exponent = -6;

    xlabel('Time (s)'), ylabel('Voltage (V)'), title('Oscilloscope Data');
    grid on, axis([-xRange/2, xRange/2, min(min1,min2)*1.25, max(max1, max2)*1.25]);

    title('~119inch fiber cable length difference')
    mix = xcorr(signal2,signal1)/1000;
    size_of_mix = size(mix);
    positive_delay_mix_sig = mix(1:round(size_of_mix(1)/2));
    [largest, idx] = max(positive_delay_mix_sig);
    hold on;
    %plot xcorr
    plot(linspace(-xRange/2,xRange/2,round((data_points(2)*2-1)/2)), positive_delay_mix_sig);
    cross_corr_delay = data_points(2)-(idx-1);
    
    fprintf('delay of 2nd in samples xcorr()= %i\n',cross_corr_delay);
    fprintf('delay of 2nd in samples finddelay()= %i\n',finddelay(signal2,signal1));
    fprintf('delay of 2nd in samples 1/3 threshold= %i\n',diff);
    time_diff_xcorr = cross_corr_delay*xRange/1000;
    fprintf('xcorr time diff = %d\n', time_diff_xcorr);
    fprintf('threshold time diff = %d\n', time_diff);
    
    %plot shifted
    plot(x,[signal1(cross_corr_delay:end)' zeros(1,cross_corr_delay-1)],'-m');
    hold off;
    legend('90% delayed','10%','90% shifted(threshold)', '1/3 threshold','1/3 threshold','xcorr',['90% shifted(xcorr cut ' num2str(ends_cut) ' points)'],'Location','Northwest')
    delay_arr = [delay_arr cross_corr_delay];
    ylabel('signal')
end

