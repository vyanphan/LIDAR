% test of I/O with DSO5054A scope!!!
clear;
%fclose(instrfind)
clf;


%open connection to oscilloscope
osc = gpib('ni',0,7);
set(osc, 'InputBufferSize', 131072);
fopen(osc);
fprintf(1,query(osc,'*IDN?'));

%Open connection to function generator
fgen = gpib('ni',0,11);
fopen(fgen);
fprintf(1,query(fgen,'*IDN?'));

%Set signal parameters on fgen
func_freq = 2e6;
func_volt = .300;
fprintf(fgen,['FREQ ' num2str(func_freq)]);
fprintf(fgen,['VOLT ' num2str(func_volt)]);
fprintf(fgen, 'FUNC:SHAP SQUARE');

%set output ON on fgen, not needed for agilent 33120A
%fprintf(fgen,'OUTP ON');


%set global parameters
samples = 1000;

%set scale and time HERE
yRange = 6;
yRange2 = .24; %.24 for dist_1; .12 for dist_2
yRange3 = .06;
xRange = .33/func_freq;
xRange = 1.9/func_freq;
fprintf(osc, [':CHANNEL1:RANGE ' num2str(yRange)])
fprintf(osc, [':CHANNEL2:RANGE ' num2str(yRange2)])
fprintf(osc, [':CHANNEL3:RANGE ' num2str(yRange3)])
fprintf(osc, ':CHANNEL1:OFFSET 0')
fprintf(osc, ':CHANNEL2:OFFSET 1.27') %1.27-.3 for dist_1 .25 FOR DIST_2
fprintf(osc, ':CHANNEL3:OFFSET 0.02')
fprintf(osc, [':TIMEBASE:RANGE ' num2str(xRange)])
fprintf(osc, [':TIMEBASE:DELay ' num2str(80e-9)])


%set format and collect data
fprintf(osc, ':ACQuire:TYPE AVERage');
fprintf(osc, ':ACQuire:COMPlete 100');
fprintf(osc, ':ACQuire:COUNt 8');
fprintf(osc, ':TRIG:SOURce CHANnel1');
fprintf(osc, ':TRIG:LEV 1');
%individual channel parameters
fprintf(osc, ':WAVeform:SOURce CHANnel1');  
fprintf(osc, ':WAVeform:Format ASCII');
fprintf(osc, [':WAVeform:POINts ' num2str(samples)]);

%collect data
fprintf(osc, ':DIG CHANnel1,CHANnel2,CHANnel3');
data = query(osc, ':WAVeform:DATA?');
fprintf(osc, ':WAVeform:SOURce CHANnel2');
fprintf(osc, ':WAVeform:Format ASCII');
fprintf(osc, [':WAVeform:POINts ' num2str(samples)]);
data2 = query(osc, ':WAVeform:DATA?');
fprintf(osc, ':WAVeform:SOURce CHANnel3');
fprintf(osc, ':WAVeform:Format ASCII');
fprintf(osc, [':WAVeform:POINts ' num2str(samples)]);
data3 = query(osc, ':WAVeform:DATA?');

%TODO parse data, definite-block length syntax
num_digits = str2double(data(2));
num_bytes = str2double( data(3:2+num_digits));
%2nd channel
num_digits2 = str2double(data2(2));
num_bytes2 = str2double( data2(3:2+num_digits2));
%3rd channel
num_digits3 = str2double(data3(2));
num_bytes3 = str2double( data2(3:2+num_digits3));

%put data in matrix format
datab = data(2+num_digits+1:2+num_digits+num_bytes);
data_parsed = eval(['[',datab,']']);
%2nd channel
data2b = data2(2+num_digits2+1:2+num_digits2+num_bytes2);
data_parsed2 = eval(['[',data2b,']']);
%3rd channel
data3b = data3(2+num_digits3+1:2+num_digits3+num_bytes3);
data_parsed3 = eval(['[',data3b,']']);


%plot data signal vs time
data_points = size(data_parsed);
x = linspace(-xRange/2,xRange/2,data_points(2));
plot(x,data_parsed,'b');
yyaxis right;
plot(x,data_parsed2,'r',x,data_parsed3,'c')

%plot graph labels
yyaxis left;
xlabel('Time (s)'), ylabel('Voltage Sync(V)'), title('Oscilloscope Data');
grid on, axis([-xRange/2, xRange/2, -yRange/2, yRange/2]);
yyaxis right;
ylabel('Voltage signal(V)');
legend('sync', '90%', '10%');

ax = gca;
ax.XAxis.Exponent = -9;


%combine and save data to file
len = size(data_parsed);
units = (1:len(2));
units(1) = xRange;
save_data = [data_parsed; data_parsed2; data_parsed3; units];
save_data = save_data.';
csvwrite(['zoom_data_' num2str(func_freq) '_hz_119.0+-.25inchcable.csv'], save_data, 0, 0);
%csvwrite(['zoom_data_' num2str(func_freq) '_hz.csv'], save_data, 0, 0);
%csvwrite(['data-', datestr(now,30), '.csv'], save_data, 0, 0);


%clean up
clear;
%
fclose(instrfind);